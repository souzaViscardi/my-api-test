
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kevinguitars',
  applicationName: 'my-aws-node-express-api-app',
  appUid: 'z7Kc9klqNFmhf3hDMh',
  orgUid: '67a1ebd1-db6f-47f6-9961-249f24a766ce',
  deploymentUid: '9c6a0a9b-ed2c-4ae4-9579-b5237ee492fe',
  serviceName: 'my-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-api-dev-updateFuncionario', timeout: 6 };

try {
  const userHandler = require('./src/controllers/Funcionario.js');
  module.exports.handler = serverlessSDK.handler(userHandler.update, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}