module.exports = {
    SUCCESS: 200,
    ERROR: 400
}