require('../database')
const Funcionario = require("./Funcionario")

module.exports = {
    Funcionario
}