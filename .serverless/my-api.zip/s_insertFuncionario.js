
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kevinguitars',
  applicationName: 'my-aws-node-express-api-app',
  appUid: 'z7Kc9klqNFmhf3hDMh',
  orgUid: '67a1ebd1-db6f-47f6-9961-249f24a766ce',
  deploymentUid: '62eb7694-2564-48ae-97ee-9be7f88f647f',
  serviceName: 'my-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-api-dev-insertFuncionario', timeout: 6 };

try {
  const userHandler = require('./src/controllers/Funcionario.js');
  module.exports.handler = serverlessSDK.handler(userHandler.insert, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}