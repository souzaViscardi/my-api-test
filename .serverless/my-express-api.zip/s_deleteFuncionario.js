
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kevinguitars',
  applicationName: 'my-aws-node-express-api-app',
  appUid: 'z7Kc9klqNFmhf3hDMh',
  orgUid: '67a1ebd1-db6f-47f6-9961-249f24a766ce',
  deploymentUid: 'bd3700ed-b139-4b77-8e98-6b866ac4b439',
  serviceName: 'my-express-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-express-api-dev-deleteFuncionario', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}